# ResumeScore MVP

## Run locally
1. Install Python 3.10+.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.
4. Export the variables (or use your preferred dotenv loader).
5. Run: `uvicorn app:app --reload`
6. Open http://127.0.0.1:8000

This MVP accepts PDF/DOCX, extracts text, calculates a basic keyword score, then uses the OpenAI Responses API for strengths, missing skills and suggestions.

**Important:** the score is a heuristic, not a guarantee of any employer's ATS result. Keep the API key on the server; never put it in browser JavaScript.
